from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo uy potencia",
	author="Bruno",
	packages=["calculos","calculos.redondear_potencia"]


	)